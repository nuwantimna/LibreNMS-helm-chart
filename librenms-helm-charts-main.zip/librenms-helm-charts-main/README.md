# LibreNMS helm chart

a helm chart to deploy libraNMS on k8s

![Architecture diagram](arch.jpg "Architecture")
